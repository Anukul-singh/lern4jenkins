Sample Java Applicaiton V3.2


